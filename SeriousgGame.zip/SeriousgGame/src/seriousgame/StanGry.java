
package seriousgame;

import static seriousgame.Parametry.*;

/**Zarządzanie stanem gry- rozpoczęcie nowej gry, zwiększenie poziomu, kolejne słowo.*/
public class StanGry {
    
    /**rozpoczęcie nowej gry (wyzerowanie parametrów)*/
    public static void odNowa(){
        
        terazPoziom=1;
        ktoreSlowo=0;
        RysowaniePanelu.punkty=0;
        RysowaniePanelu.k=0;
        RysowaniePanelu.klik=0;
        RysowaniePanelu.ktore=0;
        RysowaniePanelu.ok=0;
        RysowaniePanelu.zle=0;
        
    }//odNowa
    
    /**rozpoczęcie nowego poziomu*/
    public static void kolejnyPoziom(){
        
        terazPoziom++;
        ktoreSlowo=0;
    
    }//kolejnyPoziom
    
    /**przejście do kolejnego słowa*/
    public static void kolejneSlowo(){
        
        ktoreSlowo++;
        
    }//kolejneSlowo
}//class StanGry
