
package seriousgame;

import java.awt.Image;
import java.awt.Toolkit;
import javax.swing.ImageIcon;

/**Klasa przechowująca ważniejsze parametry gry tj. słowa dla danych poziomów, obrazki kropli
informacje odnośnie aktualnego poziomu oraz słowa, kolejność wyslosowanych liter dla słów 
w poziomach, wymiary okna.*/
public class Parametry {
    
    /**slowa na poziomie 1(kazda lietera w oddzielnej komorce)*/
    public static String[][] poziom1;
    /**slowa na poziomie 2*/
    public static String[][] poziom2;
    /**slowa na poziomie 3*/
    public static String[][] poziom3;
    /**slowa w poziomie 1 w wylosowanej kolejnosci*/
    public static String[][] los1;
    /**slowa w poziomie 2 w wylosowanej kolejnosci*/
    public static String[][] los2;
    /**slowa w poziomie 3 w wylosowanej kolejnosci*/
    public static String[][] los3;
    /**tablica do sprawdzania, czy zostala wylosowana juz dana litera (poziom1)*/
    public static int[] spr1;
    /**tablica do sprawdzania, czy zostala wylosowana juz dana litera (poziom2)*/
    public static int[] spr2;
    /**tablica do sprawdzania, czy zostala wylosowana juz dana litera (poziom3)*/
    public static int[] spr3;
    /**kolejnosc liter slow w poziomie 1*/
    public static int[][] jak1;
    /**kolejnosc liter slow w poziomie 2*/
    public static int[][] jak2;
    /**kolejnosc liter slow w poziomie 3*/
    public static int[][] jak3;
    /**tablica, w której przechowywane są obrazki opowiadające wylosowanym literom*/
    public static int[] kolejnosc;
    /**tablica z literami*/
    public static String[] alfabet;
    /**tablica kropel (obrazków) z literami*/
    public static Image[] krople;
    /**obraz na tlo*/
    public static Image tlo;
    /**aktualny poziom*/
    public static int terazPoziom;
    /**aktualnie wyswtetlane slowo*/
    public static int ktoreSlowo;
    /**szerokość gry*/
    public static int szerGry=1024;
    /**wysokość gry*/
    public static int wysGry=768;
    /**szerokość okna*/
    public static int szerokoscOkna=Toolkit.getDefaultToolkit().getScreenSize().width;
    /**wysokość okna*/
    public static int wysokoscOkna=Toolkit.getDefaultToolkit().getScreenSize().height; 
    
    /**Wczytywanie slow oraz liter alfabetu.*/
    
    public static void ladujSlowa(){
      
        poziom1 = new String[3][3];
        poziom1[0][0]="D";
        poziom1[0][1]="O";
        poziom1[0][2]="G";
        poziom1[1][0]="C";
        poziom1[1][1]="A";
        poziom1[1][2]="T";
        poziom1[2][0]="R";
        poziom1[2][1]="A";
        poziom1[2][2]="T";
        
        poziom2 = new String[3][4];
        poziom2[0][0]="B";
        poziom2[0][1]="E";
        poziom2[0][2]="A";
        poziom2[0][3]="R";
        poziom2[1][0]="F";
        poziom2[1][1]="R";
        poziom2[1][2]="O";
        poziom2[1][3]="G";
        poziom2[2][0]="B";
        poziom2[2][1]="I";
        poziom2[2][2]="R";
        poziom2[2][3]="D";
        
        poziom3 = new String[3][5];
        poziom3[0][0]="H";
        poziom3[0][1]="O";
        poziom3[0][2]="R";
        poziom3[0][3]="S";
        poziom3[0][4]="E";
        poziom3[1][0]="M";
        poziom3[1][1]="O";
        poziom3[1][2]="U";
        poziom3[1][3]="S";
        poziom3[1][4]="E";
        poziom3[2][0]="W";
        poziom3[2][1]="H";
        poziom3[2][2]="A";
        poziom3[2][3]="L";
        poziom3[2][4]="E";
        
            alfabet= new String[17];
            alfabet [0]="A";
            alfabet [1]="B";
            alfabet [2]="C";
            alfabet [3]="D";
            alfabet [4]="E";
            alfabet [5]="F";
            alfabet [6]="G";
            alfabet [7]="H";
            alfabet [8]="I";
            alfabet [9]="L";
            alfabet [10]="M";
            alfabet [11]="O";
            alfabet [12]="R";
            alfabet [13]="S";
            alfabet [14]="T";
            alfabet [15]="U";
            alfabet [16]="W";

    }//ladujSlowa
    
    /**Wczytywanie grafiki- obrazkow kropel z literkami oraz obrazu tła. */
    
        public static void ladujGrafike(){
        
            krople= new Image[17];
            krople[0]=ladujZdj("res/alfabet/A.png");
            krople[1]=ladujZdj("res/alfabet/B.png");
            krople[2]=ladujZdj("res/alfabet/C.png");
            krople[3]=ladujZdj("res/alfabet/D.png");
            krople[4]=ladujZdj("res/alfabet/E.png");
            krople[5]=ladujZdj("res/alfabet/F.png");
            krople[6]=ladujZdj("res/alfabet/G.png");
            krople[7]=ladujZdj("res/alfabet/H.png");
            krople[8]=ladujZdj("res/alfabet/I.png");
            krople[9]=ladujZdj("res/alfabet/L.png");
            krople[10]=ladujZdj("res/alfabet/M.png");
            krople[11]=ladujZdj("res/alfabet/O.png");
            krople[12]=ladujZdj("res/alfabet/R.png");
            krople[13]=ladujZdj("res/alfabet/S.png");
            krople[14]=ladujZdj("res/alfabet/T.png");
            krople[15]=ladujZdj("res/alfabet/U.png");
            krople[16]=ladujZdj("res/alfabet/W.png");
            
            
            tlo=ladujZdj("res/alfabet/tlo.png");
        }//ladujKrople
        
        /**Zaladowanie obrazkow do gry na podstawie ścieżki dostępu
        * @param nazwaPliku ścieżka do pliku
        * @return obraz */
        public static Image ladujZdj(String nazwaPliku) {
            
        return new ImageIcon(nazwaPliku).getImage();
        
    }//ladujZdj 
}//class Parametry
        

    
    
    
    

