
package seriousgame;

import java.io.FileNotFoundException;

/**Gra typu serious game do nauki języka angielskiego (słownictwa z zakresu nazw zwierząt)*/
public class Glowna {
    
    /**
     * Metoda uruchamia grę- tworzy okno gry o podanych wymiarach na środku ekranu 
     * @param args. 
     * @throws java.io.FileNotFoundException wyjatek 1
     * @throws java.lang.InterruptedException wyjatek 2 */ 
    
    public static void main(String[] args) throws FileNotFoundException, InterruptedException {
        
        //obliczenie zmiennych tak, aby okno gry stworzone zostało na środku ekranu
        int x=(Parametry.szerokoscOkna-Parametry.szerGry)/2;
        int y=(Parametry.wysokoscOkna-Parametry.wysGry)/2;
        
        //Tworzenie obiektu klasy OknoGry i tym samym wywołanie dalszej akcji
        OknoGry og= new OknoGry(Parametry.szerGry, Parametry.wysGry, x , y);
    
    }//main
    
}//class Glowna
